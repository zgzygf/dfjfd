A Pen created at CodePen.io. You can find this one at http://codepen.io/akwright/pen/ZYXPav.

 Based on this dribbble shot: http://drbl.in/nFYk by Dominik Rezek https://dribbble.com/dominikr