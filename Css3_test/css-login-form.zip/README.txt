A Pen created at CodePen.io. You can find this one at http://codepen.io/webinnov_france/pen/jEGdXb.

 Login form made with CSS and HTML. I personalized ''placeholder" attribute to make a better imagery of my form.